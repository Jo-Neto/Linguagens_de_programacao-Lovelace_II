const BtnArr = jQuery(":button");
const inpArr = $("input");

for (let i = 0; i < BtnArr.length; i++) {
    BtnArr[i].click( (i) => { makeCalc(i) });
}

function makeCalc(calcType) {
    $("#screen").text("");
    let res;
    switch (calcType) {
        case 0:
            res = Number(inpArr[0].value) + Number(inpArr[1].value);
            break;
        case 1:
            res = Number(inpArr[0].value) - Number(inpArr[1].value);
            break;
        case 2:
            res = Number(inpArr[0].value) * Number(inpArr[1].value);
            break;
        case 3:
            res = Number(inpArr[0].value) / Number(inpArr[1].value);
            break;
    }
    $("#screen").text(res);
}