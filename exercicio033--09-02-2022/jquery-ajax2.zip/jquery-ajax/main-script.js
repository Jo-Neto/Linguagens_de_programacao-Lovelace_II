$('button').click(() => {
    $.ajax(`https://cep.awesomeapi.com.br//${$('input').val()}`)
        .done((resp) => {
            if (!resp.address) {
                alert("CEP invalido");
                return;
            }
            for (let i = 0; i < ($('.showInfoP')).length; i++)
                $('.showInfoP').eq(i).html('');
            $('.showInfoP').eq(0).append(resp.address);
            $('.showInfoP').eq(1).append(resp.state);
            $('.showInfoP').eq(2).append(resp.district);
            $('.showInfoP').eq(3).append(resp.city);
            $('iframe').attr('src', `https://www.google.com/maps?api=1&center=${resp.lat}%2C${resp.lng}&hl=es;z=14&output=embed`);
        })
        .fail((resp) => {
            if (resp.status === 400) {
                alert("CEP invalido");
                return;
            }
            else if (resp.status === 404) {
                alert("CEP não encontrado");
                return;
            }
            else {
                alert("Erro de busca");
            }
        })
})