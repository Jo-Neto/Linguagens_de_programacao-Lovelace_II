$(function () {
    $("#tab").tabs({
        collapsible: true,
        active: false
      });
});

$(function () {
    $(".accordion").accordion({ heightStyle: "content"});
});

let player = [];

const ytArray = document.getElementsByTagName("iframe");

for (let i = 0; i < ytArray.length; i++) {
    player[i] = new YT.Player(ytArray[i])
}

let updaterID = setInterval(isYTready, 1000);


function isYTready() {
    let props = Object.getOwnPropertyNames(player[(ytArray.length-1)]);
    for (i of props) 
        if (i === 'getVideoData') {
            clearInterval(updaterID);
            startStuff();
        }
}

function startStuff() {
    for (let i = 0; i < player.length; i++) {
        $('h2').eq(i).text(player[i].getVideoData().title);
        $('.acc1').eq(i).text(player[i].getAvailablePlaybackRates());
        $('.acc2').eq(i).text(player[i].getDuration());
        $('.acc3').eq(i).text(player[i].getVideoBytesLoaded());
        $('.acc4').eq(i).attr('href', `https://youtu.be/CGXT6fweizE${player[i].getVideoData().video_id}`);
        $('.acc4').eq(i).text(`https://youtu.be/CGXT6fweizE${player[i].getVideoData().video_id}`);
    }
}