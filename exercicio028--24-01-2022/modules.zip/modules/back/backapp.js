const express = require('express');
const cors = require('cors');

const app = express();
const port = 8080;

app.use(cors());
app.use(express.json()); 

app.get("/birth", (req,res) => {
    const birthMod = require('./modules/birth.js');
    birthMod(req,res);
});

app.get("/sector", (req,res) => {
    const sectorMod = require('./modules/sector.js');
    sectorMod(req,res);
});

app.get("/extension", (req,res) => {
    const branchMod = require('./modules/extension.js');
    branchMod(req,res);
});

app.post("/newuser", (req,res) => {
    const newUsrMod = require('./modules/newuser.js');
    newUsrMod(req,res);
});

app.listen(port, () => { console.log(`back app listening on localhost:${port}`); });