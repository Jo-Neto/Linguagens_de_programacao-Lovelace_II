const fs = require('fs');

module.exports = function sectorfilter(req, res) {
    fs.readFile('./database.json', (err, readData) => {
        const dataBase = JSON.parse(readData);
        const filteredArr = dataBase.filter((elem) => {
            return (((elem.sector).toLowerCase()).includes((req.query.fparam).toLowerCase()));
        });
        res.json(filteredArr);
    })
};