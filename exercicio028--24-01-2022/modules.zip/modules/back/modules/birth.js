const fs = require('fs');

module.exports = function birthfilter(req, res) {
    fs.readFile('./database.json', (err, readData)=>{
        const database = JSON.parse(readData);
        const filteredArr = database.filter((elem) => {
            let workerBirthMonth = new Date(Date.parse(elem.birthDay)).getMonth();
            return (workerBirthMonth === (Number(req.query.fparam)-1));
        });
        res.json(filteredArr);
    });
};
