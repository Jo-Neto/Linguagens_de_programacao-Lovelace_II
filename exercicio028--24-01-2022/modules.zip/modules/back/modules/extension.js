const fs = require('fs');

module.exports = function branchfilter(req, res) {
    fs.readFile('./database.json', (err, readData) => {
        const database = JSON.parse(readData);
        database.sort((el1, el2) => { 
            return Number(el1.extension) - Number(el2.extension);
        });
        res.json(database);
    });
};