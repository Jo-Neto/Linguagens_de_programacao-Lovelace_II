const btnArr = document.getElementsByTagName("button");
const inpArr = document.getElementsByTagName("input");
const toAppend = document.getElementById("toAppend");
const url = 'http://localhost:8080/'

function searchDatabase(fparam, caller) {
    let value;
    value = inpArr[Number(caller)].value;
    fetch(`${url}${fparam}?fparam=${value}`)
        .then(function (response) {
            return response.json();
        })
        .then(function (myJson) {
            addToHtml(myJson);
        });
}

function addToHtml(obj) {
    toAppend.innerHTML = "";
    obj.forEach(element => {
        console.log(element);
        let el = document.createElement("p");
        let t = document.createTextNode(JSON.stringify(element));
        el.appendChild(t);
        toAppend.appendChild(el);
    });
}

function submit() {
    toAppend.innerHTML = "";
    fetch(`${url}newuser`, {
        method: 'POST',
        body: JSON.stringify({
            name: inpArr[3].value,
            email: inpArr[4].value,
            birth: inpArr[5].value,
            sector: inpArr[6].value
        }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
    .then((response) => { return response.text(); })
    .then((result) => { toAppend.innerHTML = result; });

    inpArr[3].value = "";
    inpArr[4].value = "";
    inpArr[5].value = "";
    inpArr[6].value = "";
}