const ex1inp = document.getElementsByClassName("ex-1-inp");
const ex1res = document.getElementById("ex-1-res");

const ex2inp = document.getElementsByClassName("ex-2-inp");
const ex2res = document.getElementById("ex-2-res");

const ex3show = document.getElementsByClassName("ex-3-show");
const ex3res = document.getElementById("ex-3-res");

const btnArr = document.getElementsByTagName("button");

btnArr[0].addEventListener("click", ex1btn);
btnArr[1].addEventListener("click", ex2btn);
btnArr[2].addEventListener("click", ex3btn);

//btnArr[0].addEventListener("click", btnArr[0]);
//btnArr[0].addEventListener("click", this.value????);
//btnArr[i].addEventListener("click", ex+i+btn);
//const ex1inpResp = Array.from(ex1inp, (elem => { return Number(elem.value) }));

//=========================================================================================================

function ex1btn() {
    const ex1inpResp = Array.from(ex1inp, (elem => { return Number(elem.value); }));
    ex1calc(event, ...ex1inpResp);
}

function ex1calc(event, ...choices) {
    ex1res.innerText = choices.reduce((prevVal, currVal) => { return prevVal * currVal; });
}

//==========================================================================================================

function ex2btn() {
    ex2res.innerText = [...Array.from(ex2inp[0].value), ...Array.from(ex2inp[1].value)].join('');
}

//===========================================================================================================

//can I instead of returning the HTML element, return it's innerHTML or innerText property directly
//myArray = ex3show.forEach((elem => { return elem.innerHTML; }));

function ex3btn() {
    const ex3arr = [];
    for (let i = 0; i < 10; i++) {
        ex3arr[i] = Math.floor(Math.random() * 100) + 1;
        ex3show[i].innerText = ex3arr[i];
    }
    ex3res.innerText = Math.max(...ex3arr);
}