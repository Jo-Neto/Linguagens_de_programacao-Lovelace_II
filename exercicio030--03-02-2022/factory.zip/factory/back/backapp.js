const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

app.get("/birth", (req, res) => {
    const birthMod = require('./modules/birth.js');
    birthMod(req, res);
});

app.get("/sector", (req, res) => {
    const sectorMod = require('./modules/sector.js');
    sectorMod(req, res);
});

app.get("/extension", (req, res) => {
    const branchMod = require('./modules/extension.js');
    branchMod(req, res);
});

app.post("/newuser", (req, res) => {
    const newUsrMod = require('./modules/newuser.js');
    newUsrMod(req, res);
});

app.get("/calculator", (req, res) => {
    const calcMod = require('./modules/calculator.js');
    obj = calcMod(req, res);
    let result;
    switch (Number(obj.ope)) {
        case null:
            res.send("escolha um operação");
            break;
        case 0: //add
            result = (obj.op1 + obj.op2).toString();
            res.send(result);
            break;
        case 1: //minus
            result = (obj.op1 - obj.op2).toString();
            res.send(result);
            break;
        case 2: //multiply
            result = (obj.op1 * obj.op2).toString();
            res.send(result);
            break;
        case 5: //divide
            result = (obj.op1 / obj.op2).toString();
            res.send(result);
            break;
    }
});

app.listen(port, () => { console.log(`back app listening on localhost:${port}`); });