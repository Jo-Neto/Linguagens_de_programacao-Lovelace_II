const fs = require('fs');

module.exports = function addUser(req, res) {
    fs.readFile('./database.json',  (err, readData) => { 
        const dataBase = JSON.parse(readData);
        dataBase.push(req.body);
        dataBase[Number(dataBase.length-1)].id = Number(dataBase.length);
        dataBase[Number(dataBase.length-1)].extension =  Number(rand(0,99983));
        const toWrite = JSON.stringify(dataBase);
        fs.writeFile('./database.json', toWrite, (err, out) => {});
        res.send("user created succesfully");
    });
};

function rand(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1) + min);
};