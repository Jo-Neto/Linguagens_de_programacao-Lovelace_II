module.exports = function calculator(req, res) {
    return {
        op1: req.query.op1,
        op2: req.query.op2,
        ope: req.query.ope
    }
};