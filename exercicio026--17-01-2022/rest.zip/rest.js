const field = document.getElementById("field")
const inpTemplate = document.getElementById("inp");
const add = document.getElementById("add");
const finish = document.getElementById("finish");
const resField = document.getElementById("resField");
const resBox = document.getElementById("resBox");

add.addEventListener("click", addFun);
finish.addEventListener("click", finishFun);

function addFun() { 
    const tempInp = inpTemplate.cloneNode(true);
    field.insertBefore(tempInp, add); 
}

function finishFun() {
    let inp = document.getElementsByClassName("inp");
    choiceArr = Array.from(inp, el => el.value);
    concater(...choiceArr);
}

function concater(...choiceArr) {
    resBox.innerText = choiceArr.join('');
}