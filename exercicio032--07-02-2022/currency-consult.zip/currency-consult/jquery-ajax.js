$.ajax('https://economia.awesomeapi.com.br/json/all')
    .done((resp) => {
        for (curr in resp)
            $("#coin-list-choice").append($('<option></option>').text(curr));
    });
$('#coin-list-choice').change(() => {
    $.ajax(`https://economia.awesomeapi.com.br/json/last/${$('#coin-list-choice').prop('value')}`)
        .done((resp) => {
            let currentCoin = Object.entries(resp);
            let lastDate = new Date(currentCoin[0][1].timestamp * 1000);
            let elArr = jQuery("p");
            for (let i = 0; i < elArr.length; i++)
                elArr.html('');
            $("p")[0].append(((((Number(currentCoin[0][1].ask) + Number(currentCoin[0][1].bid))) / 2)).toFixed(2));
            $("p")[1].append(lastDate.toLocaleString('pt-BR').slice(0, 10));
            $("p")[2].append(lastDate.toLocaleString('pt-BR').slice(11));
            $("p")[3].append(Number(currentCoin[0][1].high).toFixed(2));
            $("p")[4].append(Number(currentCoin[0][1].low).toFixed(2));
        })
})
$('#coin-date-search').click(() => {
    console.log($('#coin-date-choice-from').val());
    if (($('#coin-date-choice-from').val() === "" ) || ($('#coin-date-choice-to').val() === "")) {
        alert("Chose both dates first");
        return;
    }
    $.ajax(`https://economia.awesomeapi.com.br/${$('#coin-list-choice').prop('value')}/${Number.MAX_SAFE_INTEGER}?start_date=${$('#coin-date-choice-from').val().replaceAll("-", "")}&end_date=${$("#coin-date-choice-to").val().replaceAll("-", "")}`)
        .done((resp) => {
            let elArr = jQuery("p");
            for (let i = 0; i < elArr.length; i++)
                elArr.html('');
            if (resp.length === 0)
                alert("There's no data for the chosen period");
            resp.forEach(element => {
                let lastDate = new Date(element.timestamp * 1000);
                p = document.createElement("p");
                p.innerText = lastDate.toLocaleString('pt-BR').slice(11);
                $(".coin-date-choice-div")[0].append(p);
                p = document.createElement("p");
                p.innerText = lastDate.toLocaleString('pt-BR').slice(0, 10);
                $(".coin-date-choice-div")[1].append(p);
                p = document.createElement("p");
                p.innerText = (Number(element.ask) + Number(element.bid) / 2).toFixed(2);
                $(".coin-date-choice-div")[2].append(p);
            });
        })
})