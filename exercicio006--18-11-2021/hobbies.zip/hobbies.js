document.getElementById('head_1').innerHTML= "author_info";
document.getElementById('head_2').innerHTML= "hobby_info";

document.getElementById('name').innerHTML= "Jose Neto";
document.getElementById('age').innerHTML= "24 anos";
document.getElementById('place').innerHTML= "Sao Paulo";
document.getElementById("pic").setAttribute("src", "hobbies.png");

document.getElementById('title').innerHTML = "weightlifting"; 
document.getElementById('desc').innerText= "lift weights off the ground and repeat like a tard";
document.getElementById('link1').setAttribute("href", "https://en.wikipedia.org/wiki/Strength_training");
document.getElementById('link1').innerText= "saiba mais";
document.getElementById('link2').setAttribute("href", "https://www.everydayhealth.com/fitness/add-strength-training-to-your-workout.aspx");
document.getElementById('link2').innerText= "saiba um pouco mais";
document.getElementById('img1').setAttribute("src", "https://i0.wp.com/post.medicalnewstoday.com/wp-content/uploads/sites/3/2021/05/GettyImages-1056286750_header-1024x575.jpg?");
document.getElementById('img2').setAttribute("src", "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/1076/articles/2016/06/strengthtraining-1515701521.jpg?crop=1xw:0.786xh;center,top&resize=1200:*");

/*----------------------------------------------------------------

let checker_arr = document.body.children;
let id_arr;
let j=0;

for (let i=0; i<document.body.childElementCount; i++) {
    if (checker_arr[i].hasAttribute("id")) {
        id_arr[j] = checker_arr[i].getAttribute("id");
        j++;
    }
}


document.querySelectorAll([id]);

-----------------------------------------------------------------*/
